package main;

import modelo.*;
import util.InterfaceUsuario;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        InterfaceUsuario iu = new InterfaceUsuario();
        List<Financiamento> financiamentos = new ArrayList<>();

        // Cadastro via entrada do usuário para uma casa
        System.out.println("Cadastro do financiamento via entrada do usuário:");
        double valor = iu.lerValorImovel();
        int prazo = iu.lerPrazoFinanciamento();
        double taxa = iu.lerTaxaJurosAnual();

        // Dados adicionais fixos para a casa do usuário:
        double areaConstruida = 120.0;
        double areaTerreno = 250.0;

        Casa casaUsuario = new Casa(valor, prazo, taxa, areaConstruida, areaTerreno);
        financiamentos.add(casaUsuario);

        // Financiamentos fixos para teste:
        Casa casa1 = new Casa(500000, 10, 0.10, 150, 300);
        Casa casa2 = new Casa(300000, 15, 0.08, 120, 200);

        Apartamento apt1 = new Apartamento(600000, 20, 0.09, 2, 5);
        Apartamento apt2 = new Apartamento(400000, 15, 0.07, 1, 8);

        Terreno terreno1 = new Terreno(250000, 10, 0.12, "Residencial");

        financiamentos.add(casa1);
        financiamentos.add(casa2);
        financiamentos.add(apt1);
        financiamentos.add(apt2);
        financiamentos.add(terreno1);

        System.out.println("\n=== RESUMO DE TODOS OS FINANCIAMENTOS ===");
        double somaImoveis = 0;
        double somaTotal = 0;

        for (Financiamento f : financiamentos) {
            f.mostrarResumoFinanciamento();
            somaImoveis += f.getValorImovel();
            somaTotal += f.calcularTotalPagamento();
        }

        System.out.printf("Soma dos valores dos imóveis: R$ %.2f\n", somaImoveis);
        System.out.printf("Soma dos valores totais dos financiamentos: R$ %.2f\n", somaTotal);

        // Salvar dados em arquivo texto
        String arquivoTexto = "financiamentos.txt";
        salvarEmArquivoTexto(financiamentos, arquivoTexto);

        // Ler dados do arquivo texto
        lerArquivoTexto(arquivoTexto);

        // Salvar objeto serializado
        String arquivoSerializado = "financiamentos.ser";
        salvarObjetoSerializado(financiamentos, arquivoSerializado);

        // Ler objeto serializado
        List<Financiamento> financiamentosCarregados = lerObjetoSerializado(arquivoSerializado);

        if (financiamentosCarregados != null) {
            System.out.println("\n=== Financiamentos carregados do arquivo serializado ===");
            for (Financiamento f : financiamentosCarregados) {
                f.mostrarResumoFinanciamento();
            }
        }
    }

    public static void salvarEmArquivoTexto(List<Financiamento> financiamentos, String nomeArquivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nomeArquivo))) {
            for (Financiamento f : financiamentos) {
                bw.write(f.toCSV());
                bw.newLine();
            }
            System.out.println("Arquivo texto salvo com sucesso.");
        } catch (IOException e) {
            System.out.println("Erro ao salvar arquivo texto: " + e.getMessage());
        }
    }

    public static void lerArquivoTexto(String nomeArquivo) {
        System.out.println("\n--- Conteúdo do arquivo texto ---");
        try (BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                System.out.println(linha);
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler arquivo texto: " + e.getMessage());
        }
    }

    public static void salvarObjetoSerializado(List<Financiamento> financiamentos, String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            oos.writeObject(financiamentos);
            System.out.println("Arquivo serializado salvo com sucesso.");
        } catch (IOException e) {
            System.out.println("Erro ao salvar arquivo serializado: " + e.getMessage());
        }
    }

    public static List<Financiamento> lerObjetoSerializado(String nomeArquivo) {
        List<Financiamento> lista = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nomeArquivo))) {
            lista = (List<Financiamento>) ois.readObject();
            System.out.println("Arquivo serializado lido com sucesso.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro ao ler arquivo serializado: " + e.getMessage());
        }
        return lista;
    }
}
