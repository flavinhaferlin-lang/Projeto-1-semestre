package modelo;

public class Casa extends Financiamento {
    private static final long serialVersionUID = 1L;

    private double areaConstruida;
    private double areaTerreno;

    public Casa(double valorImovel, int prazo, double taxa, double areaConstruida, double areaTerreno) {
        super(valorImovel, prazo, taxa);
        this.areaConstruida = areaConstruida;
        this.areaTerreno = areaTerreno;
    }

    @Override
    public double calcularPagamentoMensal() {
        double base = getValorImovel() / (getPrazoFinanciamento() * 12);
        double juros = base * (getTaxaJurosAnual() / 12);
        double total = base + juros;

        try {
            if (80 > (juros / 2)) {
                throw new AumentoMaiorDoQueJurosException(
                        "O valor do acréscimo (R$80) é maior do que a metade do valor dos juros mensais."
                );
            }
        } catch (AumentoMaiorDoQueJurosException e) {
            System.out.println("⚠️ Exceção: " + e.getMessage());
        }

        return total + 80;
    }

    @Override
    public void mostrarResumoFinanciamento() {
        System.out.println("Tipo: Casa");
        System.out.printf("Valor do imóvel: R$ %.2f\n", getValorImovel());
        System.out.printf("Área construída: %.2f m²\n", areaConstruida);
        System.out.printf("Área do terreno: %.2f m²\n", areaTerreno);
        System.out.printf("Prazo: %d anos\n", getPrazoFinanciamento());
        System.out.printf("Taxa anual: %.2f%%\n", getTaxaJurosAnual() * 100);
        System.out.printf("Parcela mensal: R$ %.2f\n", calcularPagamentoMensal());
        System.out.printf("Total: R$ %.2f\n", calcularTotalPagamento());
        System.out.println("---------------------------");
    }

    @Override
    public String toCSV() {
        return String.format("Casa;%.2f;%.2f;%.4f;%d;%.2f;%.2f",
                getValorImovel(),
                calcularTotalPagamento(),
                getTaxaJurosAnual(),
                getPrazoFinanciamento(),
                areaConstruida,
                areaTerreno);
    }
}
