package modelo;

public class AumentoMaiorDoQueJurosException extends Exception {
    public AumentoMaiorDoQueJurosException(String mensagem) {
        super(mensagem);
    }
}
