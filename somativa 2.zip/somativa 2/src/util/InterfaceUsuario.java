package util;

import java.util.InputMismatchException;
import java.util.Scanner;

public class InterfaceUsuario {
    private Scanner scanner = new Scanner(System.in);

    public double lerValorImovel() {
        double valor = -1;
        do {
            try {
                System.out.print("Digite o valor do imóvel (positivo): ");
                valor = scanner.nextDouble();
                if (valor <= 0) {
                    System.out.println("Erro: valor precisa ser positivo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Por favor, digite um número.");
                scanner.next();
            }
        } while (valor <= 0);
        return valor;
    }

    public int lerPrazoFinanciamento() {
        int prazo = -1;
        do {
            try {
                System.out.print("Digite o prazo (em anos): ");
                prazo = scanner.nextInt();
                if (prazo <= 0) {
                    System.out.println("Erro: prazo deve ser positivo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Digite um número inteiro.");
                scanner.next();
            }
        } while (prazo <= 0);
        return prazo;
    }

    public double lerTaxaJurosAnual() {
        double taxa = -1;
        do {
            try {
                System.out.print("Digite a taxa de juros anual (ex: 0.08 para 8%): ");
                taxa = scanner.nextDouble();
                if (taxa <= 0) {
                    System.out.println("Erro: taxa precisa ser positiva.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Digite um número decimal.");
                scanner.next();
            }
        } while (taxa <= 0);
        return taxa;
    }
}
