package modelo;

public class Terreno extends Financiamento {
    private static final long serialVersionUID = 1L;

    private String tipoZona; // Exemplo: residencial, comercial

    public Terreno(double valorImovel, int prazo, double taxa, String tipoZona) {
        super(valorImovel, prazo, taxa);
        this.tipoZona = tipoZona;
    }

    @Override
    public double calcularPagamentoMensal() {
        double base = getValorImovel() / (getPrazoFinanciamento() * 12);
        double juros = base * (getTaxaJurosAnual() / 12);
        double total = base + juros;

        // Acrescenta 2% sobre o valor com juros
        total *= 1.02;

        return total;
    }

    @Override
    public void mostrarResumoFinanciamento() {
        System.out.println("Tipo: Terreno");
        System.out.printf("Valor do imóvel: R$ %.2f\n", getValorImovel());
        System.out.printf("Tipo de zona: %s\n", tipoZona);
        System.out.printf("Prazo: %d anos\n", getPrazoFinanciamento());
        System.out.printf("Taxa anual: %.2f%%\n", getTaxaJurosAnual() * 100);
        System.out.printf("Parcela mensal: R$ %.2f\n", calcularPagamentoMensal());
        System.out.printf("Total: R$ %.2f\n", calcularTotalPagamento());
        System.out.println("---------------------------");
    }

    @Override
    public String toCSV() {
        return String.format("Terreno;%.2f;%.2f;%.4f;%d;%s",
                getValorImovel(),
                calcularTotalPagamento(),
                getTaxaJurosAnual(),
                getPrazoFinanciamento(),
                tipoZona);
    }
}
