package modelo;

public class Apartamento extends Financiamento {
    private static final long serialVersionUID = 1L;

    private int numeroVagasGaragem;
    private int numeroAndar;

    public Apartamento(double valorImovel, int prazo, double taxa, int numeroVagasGaragem, int numeroAndar) {
        super(valorImovel, prazo, taxa);
        this.numeroVagasGaragem = numeroVagasGaragem;
        this.numeroAndar = numeroAndar;
    }

    @Override
    public double calcularPagamentoMensal() {
        double taxaMensal = getTaxaJurosAnual() / 12;
        int meses = getPrazoFinanciamento() * 12;
        double potencia = Math.pow(1 + taxaMensal, meses);

        double pagamentoMensal = (getValorImovel() * taxaMensal * potencia) / (potencia - 1);
        return pagamentoMensal;
    }

    @Override
    public void mostrarResumoFinanciamento() {
        System.out.println("Tipo: Apartamento");
        System.out.printf("Valor do imóvel: R$ %.2f\n", getValorImovel());
        System.out.printf("Número de vagas na garagem: %d\n", numeroVagasGaragem);
        System.out.printf("Número do andar: %d\n", numeroAndar);
        System.out.printf("Prazo: %d anos\n", getPrazoFinanciamento());
        System.out.printf("Taxa anual: %.2f%%\n", getTaxaJurosAnual() * 100);
        System.out.printf("Parcela mensal: R$ %.2f\n", calcularPagamentoMensal());
        System.out.printf("Total: R$ %.2f\n", calcularTotalPagamento());
        System.out.println("---------------------------");
    }

    @Override
    public String toCSV() {
        return String.format("Apartamento;%.2f;%.2f;%.4f;%d;%d;%d",
                getValorImovel(),
                calcularTotalPagamento(),
                getTaxaJurosAnual(),
                getPrazoFinanciamento(),
                numeroVagasGaragem,
                numeroAndar);
    }
}
